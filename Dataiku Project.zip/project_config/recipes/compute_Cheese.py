# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
Milk_cheese_and_eggs_prices_prepared = dataiku.Dataset("Milk_cheese_and_eggs_prices_prepared")
Milk_cheese_and_eggs_prices_prepared_df = Milk_cheese_and_eggs_prices_prepared.get_dataframe()

# Sample dictionary mapping error names to correct country names
error_to_country = {
    'Domin. Rep.': 'Dominican Republic',
    'R. of Congo': 'Republic of the Congo',
    'C.A. Republic': 'Central African Republic',
    'Ant.& Barb.': 'Antigua and Barbuda',
    'Tr.&Tobago': 'Trinidad and Tobago',
    'St. Vincent & ...': 'Saint Vincent and the Grenadines',
    'DR Congo': 'Democratic Republic of the Congo',
    'S.T.&Principe': 'Sao Tome and Principe',
    'UA Emirates': 'United Arab Emirates',
    'Eq. Guinea': 'Equatorial Guinea',
    'G.-Bissau': 'Guinea-Bissau',
    'Bosnia & Herz.': 'Bosnia and Herzegovina',
    'North Macedoni...': 'Macedonia',
    # Add more error-name:correct-name pairs as needed
}

# Load your dataset into a DataFrame (replace 'dataset_name' with your dataset)
Cheese_df = Milk_cheese_and_eggs_prices_prepared_df

# Replace error names with correct country names using the dictionary
Cheese_df["Countries"] = Cheese_df["Countries"].replace(error_to_country)

# If you want to handle unknown/undefined error names
# You can replace them with a placeholder or a specific value
# For example:
# df['Country'] = df['Country'].replace(error_to_country, 'Unknown')

# Write recipe outputs
Cheese = dataiku.Dataset("Cheese")
Cheese.write_with_schema(Cheese_df)
